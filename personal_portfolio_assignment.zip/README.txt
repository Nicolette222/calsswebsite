PERSONAL PORTFOLIO ASSIGNMENT

Included files:
- index.html: Home page
- projects.html: Projects/Work page
- about.html: About/Contact page
- wireframe.png: Low-fidelity layout wireframe for all three pages

Before submitting:
1. Replace generic portfolio text with your own details.
2. Replace your.email@example.com with an email address you are comfortable sharing, or remove the email link.
3. Open index.html in a browser and click every navigation link to test it.
4. Upload all three HTML files and wireframe.png to your GitHub repository.
5. Submit the GitHub repository URL in your course assignment.

No CSS is included because the assignment says CSS is not required yet.
